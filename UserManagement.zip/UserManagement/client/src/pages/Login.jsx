import { useState, useEffect } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import { useAuth } from '../context/AuthContext';
import { loginSchema } from '../utils/validationSchemas';
import { toastError } from '../utils/toast';

const Login = () => {
  const { login, isAuthenticated } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const from = location.state?.from?.pathname || '/dashboard';

  const [showPwd, setShowPwd] = useState(false);
  const [loading, setLoading] = useState(false);

  const {
    register,
    handleSubmit,
    formState: { errors },
    setValue,
  } = useForm({ resolver: yupResolver(loginSchema) });

  useEffect(() => {
    if (isAuthenticated) navigate(from, { replace: true });
  }, [isAuthenticated, navigate, from]);

  // Remember me — restore email
  useEffect(() => {
    const saved = localStorage.getItem('rememberedEmail');
    if (saved) setValue('email', saved);
  }, [setValue]);

  const onSubmit = async (data) => {
    setLoading(true);
    try {
      if (data.rememberMe) {
        localStorage.setItem('rememberedEmail', data.email);
      } else {
        localStorage.removeItem('rememberedEmail');
      }
      await login({ email: data.email, password: data.password });
      navigate(from, { replace: true });
    } catch (err) {
      const msg = err.response?.data?.message || 'Login failed. Check your credentials.';
      toastError(msg);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="auth-bg">
      <div className="glass-card auth-card fade-in">
        {/* Brand */}
        <div className="d-flex align-items-center gap-2 mb-4">
          <div className="brand-icon"><i className="bi bi-people-fill" /></div>
          <span className="brand-name">User<span>Hub</span></span>
        </div>

        <h1 className="page-title mb-1">Welcome back</h1>
        <p className="page-subtitle mb-4">Sign in to your account to continue</p>

        <form onSubmit={handleSubmit(onSubmit)} noValidate>
          {/* Email */}
          <div className="mb-3">
            <label className="form-label">Email address</label>
            <div className="input-group">
              <span className="input-group-text" style={{ background: '#F8FAFC', border: '1.5px solid #E2E8F0', borderRight: 0 }}>
                <i className="bi bi-envelope" style={{ color: 'var(--text-muted)' }} />
              </span>
              <input
                type="email"
                className={`form-control ${errors.email ? 'is-invalid' : ''}`}
                placeholder="you@example.com"
                autoComplete="email"
                {...register('email')}
              />
              {errors.email && <div className="invalid-feedback">{errors.email.message}</div>}
            </div>
          </div>

          {/* Password */}
          <div className="mb-3">
            <div className="d-flex justify-content-between align-items-center">
              <label className="form-label mb-0">Password</label>
              <Link to="/forgot-password" className="link" style={{ fontSize: '0.8rem' }}>
                Forgot password?
              </Link>
            </div>
            <div className="input-group mt-1">
              <span className="input-group-text" style={{ background: '#F8FAFC', border: '1.5px solid #E2E8F0', borderRight: 0 }}>
                <i className="bi bi-lock" style={{ color: 'var(--text-muted)' }} />
              </span>
              <input
                type={showPwd ? 'text' : 'password'}
                className={`form-control ${errors.password ? 'is-invalid' : ''}`}
                placeholder="Your password"
                autoComplete="current-password"
                {...register('password')}
              />
              <button
                type="button"
                className="input-group-text"
                style={{ background: '#F8FAFC', border: '1.5px solid #E2E8F0', borderLeft: 0, cursor: 'pointer' }}
                onClick={() => setShowPwd((v) => !v)}
              >
                <i className={`bi bi-eye${showPwd ? '-slash' : ''}`} style={{ color: 'var(--text-muted)' }} />
              </button>
              {errors.password && <div className="invalid-feedback">{errors.password.message}</div>}
            </div>
          </div>

          {/* Remember me */}
          <div className="mb-4 form-check" style={{ paddingLeft: '1.6rem' }}>
            <input type="checkbox" className="form-check-input" id="rememberMe" {...register('rememberMe')} />
            <label className="form-check-label" htmlFor="rememberMe" style={{ fontSize: '0.87rem', color: 'var(--text-secondary)' }}>
              Remember me
            </label>
          </div>

          <button
            type="submit"
            className="btn-primary-custom btn w-100 d-flex align-items-center justify-content-center gap-2"
            disabled={loading}
          >
            {loading ? (
              <><span className="spinner-border spinner-border-sm" /> Signing in…</>
            ) : (
              <><i className="bi bi-box-arrow-in-right" /> Sign in</>
            )}
          </button>
        </form>

        <div className="divider-text my-4">or</div>

        <p className="text-center" style={{ fontSize: '0.87rem', color: 'var(--text-secondary)' }}>
          Don't have an account?{' '}
          <Link to="/register" className="link">Create one — it's free</Link>
        </p>
      </div>
    </div>
  );
};

export default Login;

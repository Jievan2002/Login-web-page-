import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import { forgotPasswordSchema, resetPasswordSchema } from '../utils/validationSchemas';
import { authAPI } from '../services/authService';
import { toastSuccess, toastError } from '../utils/toast';
import PasswordStrength from '../components/PasswordStrength';

const ForgotPassword = () => {
  const navigate = useNavigate();
  const [step, setStep]           = useState(1); // 1 = verify email, 2 = new password
  const [verifiedEmail, setVerifiedEmail] = useState('');
  const [loading, setLoading]     = useState(false);
  const [showPwd, setShowPwd]     = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [pwdValue, setPwdValue]   = useState('');

  // Step 1 form
  const {
    register: r1,
    handleSubmit: h1,
    formState: { errors: e1 },
  } = useForm({ resolver: yupResolver(forgotPasswordSchema) });

  // Step 2 form
  const {
    register: r2,
    handleSubmit: h2,
    formState: { errors: e2 },
  } = useForm({ resolver: yupResolver(resetPasswordSchema) });

  const onVerifyEmail = async ({ email }) => {
    setLoading(true);
    try {
      await authAPI.forgotPassword(email);
      setVerifiedEmail(email);
      setStep(2);
      toastSuccess('Email verified! Set your new password.');
    } catch (err) {
      toastError(err.response?.data?.message || 'Email not found.');
    } finally {
      setLoading(false);
    }
  };

  const onResetPassword = async ({ newPassword, confirmPassword }) => {
    setLoading(true);
    try {
      await authAPI.resetPassword({ email: verifiedEmail, newPassword, confirmPassword });
      toastSuccess('Password reset! Please sign in.');
      navigate('/login');
    } catch (err) {
      toastError(err.response?.data?.message || 'Reset failed. Try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="auth-bg">
      <div className="glass-card auth-card fade-in">
        {/* Back + brand */}
        <div className="d-flex align-items-center justify-content-between mb-4">
          <Link to="/login" className="btn-ghost btn btn-sm d-flex align-items-center gap-1">
            <i className="bi bi-arrow-left" /> Back
          </Link>
          <div className="d-flex align-items-center gap-2">
            <div className="brand-icon" style={{ width: 32, height: 32, fontSize: '0.85rem' }}>
              <i className="bi bi-people-fill" />
            </div>
            <span className="brand-name" style={{ fontSize: '1rem' }}>User<span>Hub</span></span>
          </div>
        </div>

        {/* Step indicator */}
        <div className="d-flex align-items-center gap-2 mb-4">
          {[1, 2].map((s) => (
            <div key={s} style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
              <div style={{
                width: 28, height: 28, borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center',
                background: step >= s ? 'var(--primary)' : '#E2E8F0',
                color: step >= s ? '#fff' : 'var(--text-muted)',
                fontWeight: 700, fontSize: '0.78rem',
              }}>
                {step > s ? <i className="bi bi-check" /> : s}
              </div>
              {s < 2 && <div style={{ width: 40, height: 2, background: step > 1 ? 'var(--primary)' : '#E2E8F0', borderRadius: 2 }} />}
            </div>
          ))}
          <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)', marginLeft: 6 }}>
            {step === 1 ? 'Verify email' : 'New password'}
          </span>
        </div>

        {step === 1 ? (
          <>
            <h1 className="page-title mb-1">Reset password</h1>
            <p className="page-subtitle mb-4">Enter your account email to continue</p>
            <form onSubmit={h1(onVerifyEmail)} noValidate>
              <div className="mb-4">
                <label className="form-label">Email address</label>
                <input
                  type="email"
                  className={`form-control ${e1.email ? 'is-invalid' : ''}`}
                  placeholder="you@example.com"
                  autoComplete="email"
                  {...r1('email')}
                />
                {e1.email && <div className="invalid-feedback">{e1.email.message}</div>}
              </div>
              <button type="submit" className="btn-primary-custom btn w-100 d-flex align-items-center justify-content-center gap-2" disabled={loading}>
                {loading ? <><span className="spinner-border spinner-border-sm" /> Verifying…</> : <><i className="bi bi-search" /> Verify Email</>}
              </button>
            </form>
          </>
        ) : (
          <>
            <h1 className="page-title mb-1">New password</h1>
            <p className="page-subtitle mb-4">
              Resetting password for <strong>{verifiedEmail}</strong>
            </p>
            <form onSubmit={h2(onResetPassword)} noValidate>
              <div className="mb-3">
                <label className="form-label">New Password</label>
                <div className="input-group">
                  <input
                    type={showPwd ? 'text' : 'password'}
                    className={`form-control ${e2.newPassword ? 'is-invalid' : ''}`}
                    placeholder="Min 8 characters"
                    {...r2('newPassword', { onChange: (e) => setPwdValue(e.target.value) })}
                  />
                  <button type="button" className="input-group-text" style={{ cursor: 'pointer' }} onClick={() => setShowPwd((v) => !v)}>
                    <i className={`bi bi-eye${showPwd ? '-slash' : ''}`} />
                  </button>
                  {e2.newPassword && <div className="invalid-feedback">{e2.newPassword.message}</div>}
                </div>
                <PasswordStrength password={pwdValue} />
              </div>

              <div className="mb-4">
                <label className="form-label">Confirm Password</label>
                <div className="input-group">
                  <input
                    type={showConfirm ? 'text' : 'password'}
                    className={`form-control ${e2.confirmPassword ? 'is-invalid' : ''}`}
                    placeholder="Repeat password"
                    {...r2('confirmPassword')}
                  />
                  <button type="button" className="input-group-text" style={{ cursor: 'pointer' }} onClick={() => setShowConfirm((v) => !v)}>
                    <i className={`bi bi-eye${showConfirm ? '-slash' : ''}`} />
                  </button>
                  {e2.confirmPassword && <div className="invalid-feedback">{e2.confirmPassword.message}</div>}
                </div>
              </div>

              <button type="submit" className="btn-primary-custom btn w-100 d-flex align-items-center justify-content-center gap-2" disabled={loading}>
                {loading ? <><span className="spinner-border spinner-border-sm" /> Saving…</> : <><i className="bi bi-shield-check" /> Reset Password</>}
              </button>
            </form>
          </>
        )}

        <p className="text-center mt-3" style={{ fontSize: '0.85rem', color: 'var(--text-muted)' }}>
          Remembered it?{' '}
          <Link to="/login" className="link">Sign in</Link>
        </p>
      </div>
    </div>
  );
};

export default ForgotPassword;

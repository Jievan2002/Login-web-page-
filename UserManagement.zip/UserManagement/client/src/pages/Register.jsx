import { useState, useCallback } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import { registerSchema } from '../utils/validationSchemas';
import { authAPI, userAPI } from '../services/authService';
import { toastSuccess, toastError } from '../utils/toast';
import PasswordStrength from '../components/PasswordStrength';

const Register = () => {
  const navigate = useNavigate();
  const [showPwd, setShowPwd] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [loading, setLoading] = useState(false);
  const [emailStatus, setEmailStatus] = useState(null); // null | 'checking' | 'available' | 'taken'
  const [pwdValue, setPwdValue] = useState('');

  const {
    register,
    handleSubmit,
    formState: { errors },
    watch,
  } = useForm({ resolver: yupResolver(registerSchema) });

  const emailValue = watch('email');

  const checkEmail = useCallback(async () => {
    if (!emailValue || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(emailValue)) return;
    setEmailStatus('checking');
    try {
      const { data } = await userAPI.checkEmail(emailValue);
      setEmailStatus(data.data.available ? 'available' : 'taken');
    } catch {
      setEmailStatus(null);
    }
  }, [emailValue]);

  const onSubmit = async (data) => {
    if (emailStatus === 'taken') {
      toastError('This email is already registered.');
      return;
    }
    setLoading(true);
    try {
      await authAPI.register(data);
      toastSuccess('Account created! Please sign in.');
      navigate('/login');
    } catch (err) {
      toastError(err.response?.data?.message || 'Registration failed.');
    } finally {
      setLoading(false);
    }
  };

  const emailIndicator = () => {
    if (emailStatus === 'checking') return <span className="text-muted" style={{ fontSize: '0.75rem' }}><span className="spinner-border spinner-border-sm me-1" />Checking…</span>;
    if (emailStatus === 'available') return <span className="text-success" style={{ fontSize: '0.75rem' }}><i className="bi bi-check-circle me-1" />Available</span>;
    if (emailStatus === 'taken') return <span className="text-danger" style={{ fontSize: '0.75rem' }}><i className="bi bi-x-circle me-1" />Already registered</span>;
    return null;
  };

  return (
    <div className="auth-bg">
      <div className="glass-card auth-card auth-card-wide fade-in" style={{ maxWidth: 580 }}>
        {/* Brand */}
        <div className="d-flex align-items-center gap-2 mb-4">
          <div className="brand-icon"><i className="bi bi-people-fill" /></div>
          <span className="brand-name">User<span>Hub</span></span>
        </div>

        <h1 className="page-title mb-1">Create your account</h1>
        <p className="page-subtitle mb-4">It's free and only takes a minute</p>

        <form onSubmit={handleSubmit(onSubmit)} noValidate>
          <div className="row g-3">
            {/* Full Name */}
            <div className="col-12">
              <label className="form-label">Full Name</label>
              <input
                type="text"
                className={`form-control ${errors.name ? 'is-invalid' : ''}`}
                placeholder="Jane Smith"
                {...register('name')}
              />
              {errors.name && <div className="invalid-feedback">{errors.name.message}</div>}
            </div>

            {/* Gender */}
            <div className="col-sm-6">
              <label className="form-label">Gender</label>
              <select className={`form-select ${errors.gender ? 'is-invalid' : ''}`} {...register('gender')}>
                <option value="">Select gender</option>
                <option value="Male">Male</option>
                <option value="Female">Female</option>
                <option value="Other">Other</option>
              </select>
              {errors.gender && <div className="invalid-feedback">{errors.gender.message}</div>}
            </div>

            {/* Mobile */}
            <div className="col-sm-6">
              <label className="form-label">Mobile Number</label>
              <input
                type="tel"
                className={`form-control ${errors.mobile ? 'is-invalid' : ''}`}
                placeholder="10-digit number"
                maxLength={10}
                {...register('mobile')}
              />
              {errors.mobile && <div className="invalid-feedback">{errors.mobile.message}</div>}
            </div>

            {/* Email */}
            <div className="col-12">
              <div className="d-flex justify-content-between align-items-center mb-1">
                <label className="form-label mb-0">Email Address</label>
                {emailIndicator()}
              </div>
              <input
                type="email"
                className={`form-control ${errors.email ? 'is-invalid' : ''}`}
                placeholder="you@example.com"
                autoComplete="email"
                {...register('email')}
                onBlur={checkEmail}
              />
              {errors.email && <div className="invalid-feedback">{errors.email.message}</div>}
            </div>

            {/* Password */}
            <div className="col-sm-6">
              <label className="form-label">Password</label>
              <div className="input-group">
                <input
                  type={showPwd ? 'text' : 'password'}
                  className={`form-control ${errors.password ? 'is-invalid' : ''}`}
                  placeholder="Min 8 characters"
                  {...register('password', {
                    onChange: (e) => setPwdValue(e.target.value),
                  })}
                />
                <button type="button" className="input-group-text" style={{ cursor: 'pointer', background: '#F8FAFC', border: '1.5px solid #E2E8F0', borderLeft: 0 }} onClick={() => setShowPwd((v) => !v)}>
                  <i className={`bi bi-eye${showPwd ? '-slash' : ''}`} />
                </button>
                {errors.password && <div className="invalid-feedback">{errors.password.message}</div>}
              </div>
              <PasswordStrength password={pwdValue} />
            </div>

            {/* Confirm Password */}
            <div className="col-sm-6">
              <label className="form-label">Confirm Password</label>
              <div className="input-group">
                <input
                  type={showConfirm ? 'text' : 'password'}
                  className={`form-control ${errors.confirmPassword ? 'is-invalid' : ''}`}
                  placeholder="Repeat password"
                  {...register('confirmPassword')}
                />
                <button type="button" className="input-group-text" style={{ cursor: 'pointer', background: '#F8FAFC', border: '1.5px solid #E2E8F0', borderLeft: 0 }} onClick={() => setShowConfirm((v) => !v)}>
                  <i className={`bi bi-eye${showConfirm ? '-slash' : ''}`} />
                </button>
                {errors.confirmPassword && <div className="invalid-feedback">{errors.confirmPassword.message}</div>}
              </div>
            </div>

            {/* Address */}
            <div className="col-12">
              <label className="form-label">Address</label>
              <textarea
                className={`form-control ${errors.address ? 'is-invalid' : ''}`}
                placeholder="Street, City, State"
                rows={2}
                {...register('address')}
              />
              {errors.address && <div className="invalid-feedback">{errors.address.message}</div>}
            </div>

            {/* Pincode */}
            <div className="col-sm-6">
              <label className="form-label">Pincode</label>
              <input
                type="text"
                className={`form-control ${errors.pincode ? 'is-invalid' : ''}`}
                placeholder="6-digit code"
                maxLength={6}
                {...register('pincode')}
              />
              {errors.pincode && <div className="invalid-feedback">{errors.pincode.message}</div>}
            </div>
          </div>

          <button
            type="submit"
            className="btn-primary-custom btn w-100 mt-4 d-flex align-items-center justify-content-center gap-2"
            disabled={loading}
          >
            {loading ? (
              <><span className="spinner-border spinner-border-sm" /> Creating account…</>
            ) : (
              <><i className="bi bi-person-plus" /> Create Account</>
            )}
          </button>
        </form>

        <p className="text-center mt-3" style={{ fontSize: '0.87rem', color: 'var(--text-secondary)' }}>
          Already have an account?{' '}
          <Link to="/login" className="link">Sign in</Link>
        </p>
      </div>
    </div>
  );
};

export default Register;

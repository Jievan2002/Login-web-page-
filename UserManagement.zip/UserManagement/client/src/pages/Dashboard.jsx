import { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { userAPI } from '../services/authService';
import { toastError } from '../utils/toast';
import Swal from 'sweetalert2';
import Loader from '../components/Loader';

const InfoRow = ({ icon, label, value }) => (
  <div className="info-row">
    <div className="info-icon"><i className={`bi bi-${icon}`} /></div>
    <div>
      <div className="info-label">{label}</div>
      <div className="info-value">{value || <span style={{ color: 'var(--text-muted)' }}>—</span>}</div>
    </div>
  </div>
);

const Dashboard = () => {
  const { user: ctxUser, logout } = useAuth();
  const navigate = useNavigate();
  const [user, setUser] = useState(ctxUser);
  const [loading, setLoading] = useState(!ctxUser);

  useEffect(() => {
    if (!ctxUser) {
      (async () => {
        try {
          const { data } = await userAPI.getProfile();
          setUser(data.data.user);
        } catch {
          toastError('Failed to load profile.');
        } finally {
          setLoading(false);
        }
      })();
    } else {
      setUser(ctxUser);
      setLoading(false);
    }
  }, [ctxUser]);

  const handleLogout = async () => {
    const result = await Swal.fire({
      title: 'Sign out?',
      icon: 'question',
      showCancelButton: true,
      confirmButtonText: 'Yes, sign out',
      confirmButtonColor: '#2563EB',
      cancelButtonColor: '#64748B',
    });
    if (result.isConfirmed) {
      await logout();
      navigate('/login', { replace: true });
    }
  };

  if (loading) return <Loader />;
  if (!user) return null;

  const initials = user.name?.split(' ').map((n) => n[0]).join('').toUpperCase().slice(0, 2) || 'U';

  return (
    <div className="dashboard-layout">
      {/* Welcome header */}
      <div className="fade-in mb-4">
        <p style={{ color: 'var(--text-muted)', fontSize: '0.85rem', fontWeight: 500, textTransform: 'uppercase', letterSpacing: '0.06em' }}>
          Dashboard
        </p>
        <h1 className="dashboard-welcome">
          Welcome back, <span>{user.name?.split(' ')[0]}</span> 👋
        </h1>
        <p style={{ color: 'var(--text-secondary)', fontSize: '0.92rem', marginTop: 4 }}>
          Here's your profile overview
        </p>
      </div>

      <div className="row g-4">
        {/* Left — avatar + quick actions */}
        <div className="col-lg-3 fade-in fade-in-delay-1">
          <div className="info-card p-4 text-center mb-3">
            {/* Avatar */}
            <div style={{
              width: 80, height: 80, borderRadius: '50%', margin: '0 auto 12px',
              background: 'linear-gradient(135deg, var(--primary), #1D4ED8)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              color: '#fff', fontFamily: 'Plus Jakarta Sans, sans-serif',
              fontWeight: 700, fontSize: '1.7rem',
              boxShadow: '0 8px 24px rgba(37,99,235,0.3)',
            }}>
              {initials}
            </div>
            <div style={{ fontWeight: 700, fontSize: '1.1rem', color: 'var(--text-primary)' }}>{user.name}</div>
            <div className="stat-chip mt-2"><i className="bi bi-gender-ambiguous" />{user.gender}</div>
          </div>

          {/* Actions */}
          <div className="d-grid gap-2">
            <Link to="/edit-profile" className="btn-primary-custom btn d-flex align-items-center justify-content-center gap-2">
              <i className="bi bi-pencil-square" /> Edit Profile
            </Link>
            <button
              className="btn-ghost btn d-flex align-items-center justify-content-center gap-2"
              onClick={handleLogout}
            >
              <i className="bi bi-box-arrow-right" /> Sign Out
            </button>
          </div>
        </div>

        {/* Right — profile details */}
        <div className="col-lg-9 fade-in fade-in-delay-2">
          <div className="info-card p-4">
            <div className="d-flex align-items-center justify-content-between mb-3">
              <div>
                <h2 style={{ fontFamily: 'Plus Jakarta Sans, sans-serif', fontWeight: 700, fontSize: '1.1rem', color: 'var(--text-primary)', marginBottom: 2 }}>
                  Profile Details
                </h2>
                <p style={{ color: 'var(--text-muted)', fontSize: '0.82rem', margin: 0 }}>Your personal information</p>
              </div>
              <Link to="/edit-profile" style={{ color: 'var(--primary)', fontSize: '0.82rem', fontWeight: 600, textDecoration: 'none' }}>
                <i className="bi bi-pencil me-1" />Edit
              </Link>
            </div>

            <InfoRow icon="person"          label="Full Name"      value={user.name} />
            <InfoRow icon="gender-ambiguous" label="Gender"         value={user.gender} />
            <InfoRow icon="phone"            label="Mobile"         value={user.mobile} />
            <InfoRow icon="envelope"         label="Email"          value={user.email} />
            <InfoRow icon="geo-alt"          label="Address"        value={user.address} />
            <InfoRow icon="mailbox"          label="Pincode"        value={user.pincode} />
            <InfoRow
              icon="calendar3"
              label="Member Since"
              value={new Date(user.created_at).toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric' })}
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;

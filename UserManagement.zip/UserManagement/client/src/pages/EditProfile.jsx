import { useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import { useAuth } from '../context/AuthContext';
import { userAPI } from '../services/authService';
import { editProfileSchema } from '../utils/validationSchemas';
import { toastSuccess, toastError } from '../utils/toast';

const EditProfile = () => {
  const { user, updateUser } = useAuth();
  const navigate = useNavigate();

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors, isDirty, isSubmitting },
  } = useForm({
    resolver: yupResolver(editProfileSchema),
    defaultValues: {
      name:    user?.name    || '',
      gender:  user?.gender  || '',
      mobile:  user?.mobile  || '',
      address: user?.address || '',
      pincode: user?.pincode || '',
    },
  });

  // Sync form when user data arrives
  useEffect(() => {
    if (user) {
      reset({
        name:    user.name,
        gender:  user.gender,
        mobile:  user.mobile,
        address: user.address,
        pincode: user.pincode,
      });
    }
  }, [user, reset]);

  const onSubmit = async (data) => {
    try {
      const { data: res } = await userAPI.updateProfile(data);
      updateUser(res.data.user);
      toastSuccess('Profile updated!');
      navigate('/dashboard');
    } catch (err) {
      toastError(err.response?.data?.message || 'Update failed.');
    }
  };

  return (
    <div className="auth-bg" style={{ background: 'var(--bg)' }}>
      <div className="glass-card auth-card auth-card-wide fade-in" style={{ maxWidth: 560, marginTop: 20, marginBottom: 20 }}>
        {/* Header */}
        <div className="d-flex align-items-center justify-content-between mb-4">
          <Link to="/dashboard" className="btn-ghost btn btn-sm d-flex align-items-center gap-1">
            <i className="bi bi-arrow-left" /> Back
          </Link>
          <div className="d-flex align-items-center gap-2">
            <div className="brand-icon" style={{ width: 32, height: 32, fontSize: '0.85rem' }}>
              <i className="bi bi-people-fill" />
            </div>
            <span className="brand-name" style={{ fontSize: '1rem' }}>User<span>Hub</span></span>
          </div>
        </div>

        <h1 className="page-title mb-1">Edit Profile</h1>
        <p className="page-subtitle mb-4">Update your personal information</p>

        <form onSubmit={handleSubmit(onSubmit)} noValidate>
          <div className="row g-3">
            {/* Full Name */}
            <div className="col-12">
              <label className="form-label">Full Name</label>
              <input
                type="text"
                className={`form-control ${errors.name ? 'is-invalid' : ''}`}
                placeholder="Jane Smith"
                {...register('name')}
              />
              {errors.name && <div className="invalid-feedback">{errors.name.message}</div>}
            </div>

            {/* Gender */}
            <div className="col-sm-6">
              <label className="form-label">Gender</label>
              <select className={`form-select ${errors.gender ? 'is-invalid' : ''}`} {...register('gender')}>
                <option value="">Select gender</option>
                <option value="Male">Male</option>
                <option value="Female">Female</option>
                <option value="Other">Other</option>
              </select>
              {errors.gender && <div className="invalid-feedback">{errors.gender.message}</div>}
            </div>

            {/* Mobile */}
            <div className="col-sm-6">
              <label className="form-label">Mobile Number</label>
              <input
                type="tel"
                className={`form-control ${errors.mobile ? 'is-invalid' : ''}`}
                placeholder="10-digit number"
                maxLength={10}
                {...register('mobile')}
              />
              {errors.mobile && <div className="invalid-feedback">{errors.mobile.message}</div>}
            </div>

            {/* Email — read only */}
            <div className="col-12">
              <label className="form-label">Email Address</label>
              <div className="d-flex align-items-center gap-2">
                <input
                  type="email"
                  className="form-control"
                  value={user?.email || ''}
                  readOnly
                  style={{ background: '#F1F5F9', color: 'var(--text-muted)', cursor: 'not-allowed' }}
                />
                <span className="stat-chip" style={{ whiteSpace: 'nowrap', fontSize: '0.72rem' }}>
                  <i className="bi bi-lock" /> Locked
                </span>
              </div>
              <small className="text-muted" style={{ fontSize: '0.75rem' }}>Email cannot be changed</small>
            </div>

            {/* Address */}
            <div className="col-12">
              <label className="form-label">Address</label>
              <textarea
                className={`form-control ${errors.address ? 'is-invalid' : ''}`}
                placeholder="Street, City, State"
                rows={2}
                {...register('address')}
              />
              {errors.address && <div className="invalid-feedback">{errors.address.message}</div>}
            </div>

            {/* Pincode */}
            <div className="col-sm-6">
              <label className="form-label">Pincode</label>
              <input
                type="text"
                className={`form-control ${errors.pincode ? 'is-invalid' : ''}`}
                placeholder="6-digit code"
                maxLength={6}
                {...register('pincode')}
              />
              {errors.pincode && <div className="invalid-feedback">{errors.pincode.message}</div>}
            </div>
          </div>

          <div className="d-grid gap-2 mt-4">
            <button
              type="submit"
              className="btn-primary-custom btn d-flex align-items-center justify-content-center gap-2"
              disabled={isSubmitting || !isDirty}
            >
              {isSubmitting ? (
                <><span className="spinner-border spinner-border-sm" /> Saving…</>
              ) : (
                <><i className="bi bi-check2-circle" /> Save Changes</>
              )}
            </button>
            <Link to="/dashboard" className="btn-ghost btn text-center">
              Cancel
            </Link>
          </div>
        </form>
      </div>
    </div>
  );
};

export default EditProfile;

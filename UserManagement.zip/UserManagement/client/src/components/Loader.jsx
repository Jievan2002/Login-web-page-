const Loader = ({ fullScreen = true, size = 48 }) => {
  if (fullScreen) {
    return (
      <div className="spinner-overlay">
        <div className="spinner-ring" style={{ width: size, height: size }} />
      </div>
    );
  }
  return (
    <div className="d-flex justify-content-center align-items-center py-4">
      <div className="spinner-ring" style={{ width: 32, height: 32 }} />
    </div>
  );
};

export default Loader;

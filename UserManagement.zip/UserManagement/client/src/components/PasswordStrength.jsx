import { useMemo } from 'react';

const LEVELS = [
  { label: 'Very Weak', color: '#EF4444', pct: 20 },
  { label: 'Weak',      color: '#F97316', pct: 40 },
  { label: 'Fair',      color: '#EAB308', pct: 60 },
  { label: 'Strong',    color: '#22C55E', pct: 80 },
  { label: 'Very Strong', color: '#16A34A', pct: 100 },
];

const scorePassword = (password) => {
  if (!password) return -1;
  let score = 0;
  if (password.length >= 8)   score++;
  if (password.length >= 12)  score++;
  if (/[A-Z]/.test(password)) score++;
  if (/[a-z]/.test(password)) score++;
  if (/[0-9]/.test(password)) score++;
  if (/[^A-Za-z0-9]/.test(password)) score++;
  // Map 0-6 to 0-4
  return Math.min(Math.floor(score * (5 / 6)), 4);
};

const PasswordStrength = ({ password }) => {
  const score = useMemo(() => scorePassword(password), [password]);

  if (score < 0 || !password) return null;

  const level = LEVELS[score];
  return (
    <div className="mt-2">
      <div className="strength-bar-track">
        <div
          className="strength-bar-fill"
          style={{ width: `${level.pct}%`, background: level.color }}
        />
      </div>
      <div className="d-flex justify-content-between align-items-center mt-1">
        <span style={{ fontSize: '0.75rem', color: level.color, fontWeight: 600 }}>
          {level.label}
        </span>
        <span style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}>
          {score < 3 ? 'Add uppercase, numbers & symbols' : 'Good password!'}
        </span>
      </div>
    </div>
  );
};

export default PasswordStrength;

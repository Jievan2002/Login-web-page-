const Footer = () => (
  <footer className="app-footer">
    <span>© {new Date().getFullYear()} UserHub &mdash; All rights reserved</span>
    {' · '}
    <a href="#privacy">Privacy</a>
    {' · '}
    <a href="#terms">Terms</a>
  </footer>
);

export default Footer;

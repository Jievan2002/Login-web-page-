import { Component } from 'react';

class ErrorBoundary extends Component {
  state = { hasError: false, error: null };

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, info) {
    console.error('ErrorBoundary caught:', error, info);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="auth-bg">
          <div className="glass-card auth-card text-center">
            <div style={{ fontSize: '3rem', marginBottom: '1rem' }}>⚠️</div>
            <h2 className="page-title mb-2">Something went wrong</h2>
            <p className="page-subtitle mb-4">{this.state.error?.message || 'An unexpected error occurred.'}</p>
            <button
              className="btn-primary-custom btn w-100"
              onClick={() => { this.setState({ hasError: false }); window.location.href = '/'; }}
            >
              Return to Home
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

export default ErrorBoundary;

import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import Swal from 'sweetalert2';
import { useTheme } from '../hooks/useTheme';

const Navbar = () => {
  const { user, logout, isAuthenticated } = useAuth();
  const navigate = useNavigate();
  const { dark, toggle } = useTheme();

  const handleLogout = async () => {
    const result = await Swal.fire({
      title: 'Sign out?',
      text: "You'll need to log in again to access your account.",
      icon: 'question',
      showCancelButton: true,
      confirmButtonText: 'Yes, sign out',
      cancelButtonText: 'Cancel',
      confirmButtonColor: '#2563EB',
      cancelButtonColor: '#64748B',
      borderRadius: '14px',
    });
    if (result.isConfirmed) {
      await logout();
      navigate('/login', { replace: true });
    }
  };

  const initials = user?.name
    ? user.name.split(' ').map((n) => n[0]).join('').toUpperCase().slice(0, 2)
    : 'U';

  return (
    <nav className="app-navbar">
      <div className="navbar-inner">
        {/* Brand */}
        <Link to={isAuthenticated ? '/dashboard' : '/login'} className="brand-mark">
          <div className="brand-icon"><i className="bi bi-people-fill" /></div>
          <span className="brand-name">User<span>Hub</span></span>
        </Link>

        {/* Right side */}
        <div className="d-flex align-items-center gap-2">
          {/* Theme toggle */}
          <button className="theme-toggle" onClick={toggle} title="Toggle theme">
            <i className={`bi bi-${dark ? 'sun' : 'moon'}`} />
          </button>

          {isAuthenticated && user && (
            <>
              <Link to="/dashboard" className="btn-ghost btn btn-sm d-none d-md-inline-flex">
                <i className="bi bi-grid me-1" /> Dashboard
              </Link>
              <Link to="/edit-profile" className="btn-ghost btn btn-sm d-none d-md-inline-flex">
                <i className="bi bi-pencil me-1" /> Edit Profile
              </Link>
              <button className="nav-user-chip" onClick={handleLogout}>
                <div className="nav-avatar">{initials}</div>
                <span className="d-none d-sm-inline">{user.name?.split(' ')[0]}</span>
                <i className="bi bi-box-arrow-right" style={{ fontSize: '0.8rem' }} />
              </button>
            </>
          )}

          {!isAuthenticated && (
            <Link to="/login" className="btn-primary-custom btn btn-sm">
              Sign in <i className="bi bi-arrow-right ms-1" />
            </Link>
          )}
        </div>
      </div>
    </nav>
  );
};

export default Navbar;

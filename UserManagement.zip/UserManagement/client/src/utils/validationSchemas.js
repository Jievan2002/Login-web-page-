import * as yup from 'yup';

const PASSWORD_RULES = yup
  .string()
  .min(8, 'At least 8 characters')
  .matches(/[A-Z]/, 'Must contain an uppercase letter')
  .matches(/[a-z]/, 'Must contain a lowercase letter')
  .matches(/[0-9]/, 'Must contain a number')
  .matches(/[^A-Za-z0-9]/, 'Must contain a special character')
  .required('Password is required');

export const loginSchema = yup.object({
  email:    yup.string().email('Enter a valid email').required('Email is required'),
  password: yup.string().required('Password is required'),
});

export const registerSchema = yup.object({
  name: yup
    .string()
    .min(3, 'Minimum 3 characters')
    .required('Full name is required'),
  gender: yup
    .string()
    .oneOf(['Male', 'Female', 'Other'], 'Select a gender')
    .required('Gender is required'),
  mobile: yup
    .string()
    .matches(/^[0-9]{10}$/, 'Mobile must be exactly 10 digits')
    .required('Mobile is required'),
  email: yup
    .string()
    .email('Enter a valid email')
    .required('Email is required'),
  password: PASSWORD_RULES,
  confirmPassword: yup
    .string()
    .oneOf([yup.ref('password')], 'Passwords do not match')
    .required('Please confirm your password'),
  address: yup.string().required('Address is required'),
  pincode: yup
    .string()
    .matches(/^[0-9]{6}$/, 'Pincode must be exactly 6 digits')
    .required('Pincode is required'),
});

export const forgotPasswordSchema = yup.object({
  email: yup.string().email('Enter a valid email').required('Email is required'),
});

export const resetPasswordSchema = yup.object({
  newPassword: PASSWORD_RULES,
  confirmPassword: yup
    .string()
    .oneOf([yup.ref('newPassword')], 'Passwords do not match')
    .required('Please confirm your password'),
});

export const editProfileSchema = yup.object({
  name:    yup.string().min(3, 'Minimum 3 characters').required('Name is required'),
  gender:  yup.string().oneOf(['Male', 'Female', 'Other']).required('Gender is required'),
  mobile:  yup.string().matches(/^[0-9]{10}$/, '10 digits required').required('Mobile is required'),
  address: yup.string().required('Address is required'),
  pincode: yup.string().matches(/^[0-9]{6}$/, '6 digits required').required('Pincode is required'),
});

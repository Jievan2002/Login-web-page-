import Swal from 'sweetalert2';

const Toast = Swal.mixin({
  toast: true,
  position: 'top-end',
  showConfirmButton: false,
  timer: 3500,
  timerProgressBar: true,
  didOpen: (toast) => {
    toast.onmouseenter = Swal.stopTimer;
    toast.onmouseleave = Swal.resumeTimer;
  },
});

export const toastSuccess = (msg) => Toast.fire({ icon: 'success', title: msg });
export const toastError   = (msg) => Toast.fire({ icon: 'error',   title: msg });
export const toastInfo    = (msg) => Toast.fire({ icon: 'info',    title: msg });
export const toastWarning = (msg) => Toast.fire({ icon: 'warning', title: msg });

export const alertSuccess = (title, text = '') =>
  Swal.fire({ icon: 'success', title, text, confirmButtonColor: '#2563EB' });

export const alertError = (title, text = '') =>
  Swal.fire({ icon: 'error', title, text, confirmButtonColor: '#DC2626' });

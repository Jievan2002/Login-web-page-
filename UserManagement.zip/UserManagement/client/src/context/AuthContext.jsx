import { createContext, useContext, useReducer, useEffect, useCallback } from 'react';
import { authAPI, userAPI } from '../services/authService';

/* ── State shape ────────────────────────────────────────────── */
const initialState = {
  user: null,
  isAuthenticated: false,
  loading: true,   // true while we attempt silent auto-login
};

/* ── Reducer ────────────────────────────────────────────────── */
const authReducer = (state, action) => {
  switch (action.type) {
    case 'SET_USER':
      return { ...state, user: action.payload, isAuthenticated: true, loading: false };
    case 'CLEAR_USER':
      return { ...state, user: null, isAuthenticated: false, loading: false };
    case 'SET_LOADING':
      return { ...state, loading: action.payload };
    case 'UPDATE_USER':
      return { ...state, user: { ...state.user, ...action.payload } };
    default:
      return state;
  }
};

/* ── Context ────────────────────────────────────────────────── */
const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [state, dispatch] = useReducer(authReducer, initialState);

  /** Attempt silent restore on mount */
  useEffect(() => {
    (async () => {
      try {
        const { data } = await userAPI.getProfile();
        dispatch({ type: 'SET_USER', payload: data.data.user });
      } catch {
        dispatch({ type: 'CLEAR_USER' });
      }
    })();
  }, []);

  const login = useCallback(async (credentials) => {
    const { data } = await authAPI.login(credentials);
    dispatch({ type: 'SET_USER', payload: data.data.user });
    return data;
  }, []);

  const logout = useCallback(async () => {
    try { await authAPI.logout(); } catch { /* ignore */ }
    dispatch({ type: 'CLEAR_USER' });
  }, []);

  const updateUser = useCallback((userData) => {
    dispatch({ type: 'UPDATE_USER', payload: userData });
  }, []);

  return (
    <AuthContext.Provider value={{ ...state, login, logout, updateUser }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used inside AuthProvider');
  return ctx;
};

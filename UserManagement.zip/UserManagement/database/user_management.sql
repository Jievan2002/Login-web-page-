-- ============================================================
-- User Management System - Database Script
-- Database: user_management
-- ============================================================

CREATE DATABASE IF NOT EXISTS user_management
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE user_management;

-- ============================================================
-- Table: users
-- ============================================================
CREATE TABLE IF NOT EXISTS users (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  name        VARCHAR(100)  NOT NULL,
  gender      ENUM('Male','Female','Other') NOT NULL,
  mobile      CHAR(10)      NOT NULL,
  email       VARCHAR(150)  NOT NULL,
  password    VARCHAR(255)  NOT NULL,
  address     TEXT          NOT NULL,
  pincode     CHAR(6)       NOT NULL,
  created_at  DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at  DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  CONSTRAINT uq_users_email  UNIQUE (email),
  CONSTRAINT uq_users_mobile UNIQUE (mobile)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- Indexes
-- ============================================================
CREATE INDEX idx_users_email   ON users (email);
CREATE INDEX idx_users_mobile  ON users (mobile);
CREATE INDEX idx_users_created ON users (created_at);

-- ============================================================
-- Table: refresh_tokens  (persisted refresh token store)
-- ============================================================
CREATE TABLE IF NOT EXISTS refresh_tokens (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  user_id     INT          NOT NULL,
  token       TEXT         NOT NULL,
  expires_at  DATETIME     NOT NULL,
  created_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,

  CONSTRAINT fk_rt_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX idx_rt_user ON refresh_tokens (user_id);

-- ============================================================
-- Sample Users  (password = "Admin@1234")
-- bcrypt hash generated with saltRounds=12 for "Admin@1234"
-- ============================================================
INSERT INTO users (name, gender, mobile, email, password, address, pincode) VALUES
(
  'Alice Johnson',
  'Female',
  '9876543210',
  'alice@example.com',
  '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj4J/HS.iN9e',
  '123 Main Street, Springfield',
  '560001'
),
(
  'Bob Smith',
  'Male',
  '9123456780',
  'bob@example.com',
  '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj4J/HS.iN9e',
  '456 Oak Avenue, Shelbyville',
  '400001'
),
(
  'Charlie Dev',
  'Other',
  '9000000001',
  'charlie@example.com',
  '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj4J/HS.iN9e',
  '789 Pine Road, Capital City',
  '110001'
);

const { verifyAccessToken } = require('../utils/jwt');
const { sendError } = require('../utils/response');

/**
 * Protect routes.
 * Reads JWT from HttpOnly cookie `accessToken` OR from Authorization: Bearer header.
 */
const protect = (req, res, next) => {
  try {
    let token =
      req.cookies?.accessToken ||
      (req.headers.authorization?.startsWith('Bearer ')
        ? req.headers.authorization.split(' ')[1]
        : null);

    if (!token) {
      return sendError(res, 'Not authenticated. Please log in.', 401);
    }

    const decoded = verifyAccessToken(token);
    req.user = decoded; // { id, email, iat, exp }
    next();
  } catch (err) {
    if (err.name === 'TokenExpiredError') {
      return sendError(res, 'Session expired. Please log in again.', 401);
    }
    return sendError(res, 'Invalid token.', 401);
  }
};

module.exports = { protect };

const { body, validationResult } = require('express-validator');
const { sendError } = require('../utils/response');

/** Run validation chain and short-circuit if errors exist */
const validate = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return sendError(res, 'Validation failed', 422, errors.array());
  }
  next();
};

/* ── Registration rules ─────────────────────────────────────── */
const registerRules = [
  body('name')
    .trim()
    .notEmpty().withMessage('Name is required')
    .isLength({ min: 3 }).withMessage('Name must be at least 3 characters'),

  body('gender')
    .isIn(['Male', 'Female', 'Other']).withMessage('Gender must be Male, Female, or Other'),

  body('mobile')
    .trim()
    .matches(/^[0-9]{10}$/).withMessage('Mobile must be exactly 10 digits'),

  body('email')
    .trim()
    .normalizeEmail()
    .isEmail().withMessage('Valid email is required'),

  body('password')
    .isLength({ min: 8 }).withMessage('Password must be at least 8 characters')
    .matches(/[A-Z]/).withMessage('Password must contain an uppercase letter')
    .matches(/[a-z]/).withMessage('Password must contain a lowercase letter')
    .matches(/[0-9]/).withMessage('Password must contain a number')
    .matches(/[^A-Za-z0-9]/).withMessage('Password must contain a special character'),

  body('confirmPassword')
    .custom((value, { req }) => {
      if (value !== req.body.password) throw new Error('Passwords do not match');
      return true;
    }),

  body('address').trim().notEmpty().withMessage('Address is required'),

  body('pincode')
    .trim()
    .matches(/^[0-9]{6}$/).withMessage('Pincode must be exactly 6 digits'),
];

/* ── Login rules ─────────────────────────────────────────────── */
const loginRules = [
  body('email').trim().normalizeEmail().isEmail().withMessage('Valid email is required'),
  body('password').notEmpty().withMessage('Password is required'),
];

/* ── Forgot-password rules ───────────────────────────────────── */
const forgotPasswordRules = [
  body('email').trim().normalizeEmail().isEmail().withMessage('Valid email is required'),
];

const resetPasswordRules = [
  body('email').trim().normalizeEmail().isEmail().withMessage('Valid email is required'),
  body('newPassword')
    .isLength({ min: 8 }).withMessage('Password must be at least 8 characters')
    .matches(/[A-Z]/).withMessage('Must contain uppercase')
    .matches(/[a-z]/).withMessage('Must contain lowercase')
    .matches(/[0-9]/).withMessage('Must contain a number')
    .matches(/[^A-Za-z0-9]/).withMessage('Must contain a special character'),
  body('confirmPassword')
    .custom((value, { req }) => {
      if (value !== req.body.newPassword) throw new Error('Passwords do not match');
      return true;
    }),
];

/* ── Profile update rules ────────────────────────────────────── */
const updateProfileRules = [
  body('name').trim().notEmpty().withMessage('Name is required').isLength({ min: 3 }).withMessage('Min 3 chars'),
  body('gender').isIn(['Male', 'Female', 'Other']).withMessage('Invalid gender'),
  body('mobile').trim().matches(/^[0-9]{10}$/).withMessage('Mobile must be 10 digits'),
  body('address').trim().notEmpty().withMessage('Address is required'),
  body('pincode').trim().matches(/^[0-9]{6}$/).withMessage('Pincode must be 6 digits'),
];

module.exports = {
  validate,
  registerRules,
  loginRules,
  forgotPasswordRules,
  resetPasswordRules,
  updateProfileRules,
};

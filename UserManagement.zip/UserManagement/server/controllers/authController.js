const authService = require('../services/authService');
const { sendSuccess, sendError } = require('../utils/response');
const { parseDuration } = require('../utils/jwt');

const COOKIE_OPTS = (maxAgeMs) => ({
  httpOnly: true,
  secure: process.env.NODE_ENV === 'production',
  sameSite: process.env.NODE_ENV === 'production' ? 'strict' : 'lax',
  maxAge: maxAgeMs,
});

/* ── POST /api/auth/register ─────────────────────────────────── */
exports.register = async (req, res) => {
  try {
    const user = await authService.register(req.body);
    return sendSuccess(res, { user }, 'Registration successful', 201);
  } catch (err) {
    return sendError(res, err.message, err.status || 500);
  }
};

/* ── POST /api/auth/login ────────────────────────────────────── */
exports.login = async (req, res) => {
  try {
    const { email, password } = req.body;
    const { accessToken, refreshToken, user } = await authService.login(email, password);

    res.cookie(
      'accessToken',
      accessToken,
      COOKIE_OPTS(parseDuration(process.env.JWT_EXPIRES_IN || '15m'))
    );
    res.cookie(
      'refreshToken',
      refreshToken,
      COOKIE_OPTS(parseDuration(process.env.REFRESH_TOKEN_EXPIRES_IN || '7d'))
    );

    return sendSuccess(res, { user, accessToken }, 'Login successful');
  } catch (err) {
    return sendError(res, err.message, err.status || 500);
  }
};

/* ── POST /api/auth/logout ───────────────────────────────────── */
exports.logout = async (req, res) => {
  try {
    const refreshToken = req.cookies?.refreshToken;
    await authService.logout(refreshToken);

    res.clearCookie('accessToken');
    res.clearCookie('refreshToken');
    return sendSuccess(res, {}, 'Logged out successfully');
  } catch (err) {
    return sendError(res, err.message, err.status || 500);
  }
};

/* ── POST /api/auth/refresh ──────────────────────────────────── */
exports.refresh = async (req, res) => {
  try {
    const token = req.cookies?.refreshToken;
    if (!token) return sendError(res, 'No refresh token', 401);

    const { accessToken } = await authService.refreshAccessToken(token);

    res.cookie(
      'accessToken',
      accessToken,
      COOKIE_OPTS(parseDuration(process.env.JWT_EXPIRES_IN || '15m'))
    );
    return sendSuccess(res, { accessToken }, 'Token refreshed');
  } catch (err) {
    return sendError(res, err.message, err.status || 401);
  }
};

/* ── POST /api/auth/forgot-password ─────────────────────────── */
exports.forgotPassword = async (req, res) => {
  try {
    const { email } = req.body;
    await authService.checkEmailExists(email);
    return sendSuccess(res, {}, 'Email verified. You may now reset your password.');
  } catch (err) {
    return sendError(res, err.message, err.status || 500);
  }
};

/* ── POST /api/auth/reset-password ──────────────────────────── */
exports.resetPassword = async (req, res) => {
  try {
    const { email, newPassword } = req.body;
    await authService.resetPassword(email, newPassword);
    return sendSuccess(res, {}, 'Password reset successful. Please log in.');
  } catch (err) {
    return sendError(res, err.message, err.status || 500);
  }
};

const userService = require('../services/userService');
const { sendSuccess, sendError } = require('../utils/response');

/* ── GET /api/users/profile ──────────────────────────────────── */
exports.getProfile = async (req, res) => {
  try {
    const user = await userService.getProfile(req.user.id);
    return sendSuccess(res, { user });
  } catch (err) {
    return sendError(res, err.message, err.status || 500);
  }
};

/* ── PUT /api/users/profile ──────────────────────────────────── */
exports.updateProfile = async (req, res) => {
  try {
    const user = await userService.updateProfile(req.user.id, req.body);
    return sendSuccess(res, { user }, 'Profile updated successfully');
  } catch (err) {
    return sendError(res, err.message, err.status || 500);
  }
};

/* ── GET /api/users  (admin-ready) ──────────────────────────── */
exports.getAllUsers = async (req, res) => {
  try {
    const users = await userService.getAllUsers();
    return sendSuccess(res, { users, count: users.length });
  } catch (err) {
    return sendError(res, err.message, err.status || 500);
  }
};

/* ── GET /api/users/check-email?email=... ────────────────────── */
exports.checkEmail = async (req, res) => {
  try {
    const { email } = req.query;
    if (!email) return sendError(res, 'Email query param required', 400);
    const available = await userService.checkEmailAvailability(email);
    return sendSuccess(res, { available });
  } catch (err) {
    return sendError(res, err.message, err.status || 500);
  }
};

const router = require('express').Router();
const authController = require('../controllers/authController');
const {
  validate,
  registerRules,
  loginRules,
  forgotPasswordRules,
  resetPasswordRules,
} = require('../middleware/validationMiddleware');

router.post('/register',        registerRules,       validate, authController.register);
router.post('/login',           loginRules,          validate, authController.login);
router.post('/logout',                                         authController.logout);
router.post('/refresh',                                        authController.refresh);
router.post('/forgot-password', forgotPasswordRules, validate, authController.forgotPassword);
router.post('/reset-password',  resetPasswordRules,  validate, authController.resetPassword);

module.exports = router;

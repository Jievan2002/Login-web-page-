const router = require('express').Router();
const userController = require('../controllers/userController');
const { protect } = require('../middleware/authMiddleware');
const { validate, updateProfileRules } = require('../middleware/validationMiddleware');

// Email availability check — public
router.get('/check-email', userController.checkEmail);

// Protected routes
router.use(protect);

router.get('/profile',                                           userController.getProfile);
router.put('/profile', updateProfileRules, validate,            userController.updateProfile);
router.get('/',                                                   userController.getAllUsers);

module.exports = router;

const User = require('../models/User');

/* ── Get profile ─────────────────────────────────────────────── */
const getProfile = async (userId) => {
  const user = await User.findByPk(userId, {
    attributes: { exclude: ['password'] },
  });
  if (!user) throw Object.assign(new Error('User not found'), { status: 404 });
  return user;
};

/* ── Update profile ──────────────────────────────────────────── */
const updateProfile = async (userId, { name, gender, mobile, address, pincode }) => {
  const user = await User.findByPk(userId);
  if (!user) throw Object.assign(new Error('User not found'), { status: 404 });

  // Check mobile uniqueness for other users
  if (mobile !== user.mobile) {
    const mobileExists = await User.findOne({ where: { mobile } });
    if (mobileExists) throw Object.assign(new Error('Mobile already in use'), { status: 409 });
  }

  await user.update({ name, gender, mobile, address, pincode });

  const { password, ...safe } = user.toJSON();
  return safe;
};

/* ── List all users (admin-ready) ────────────────────────────── */
const getAllUsers = async () => {
  const users = await User.findAll({
    attributes: { exclude: ['password'] },
    order: [['created_at', 'DESC']],
  });
  return users;
};

/* ── Check email availability ────────────────────────────────── */
const checkEmailAvailability = async (email) => {
  const user = await User.findOne({ where: { email } });
  return !user; // true = available
};

module.exports = { getProfile, updateProfile, getAllUsers, checkEmailAvailability };

const bcrypt = require('bcrypt');
const User = require('../models/User');
const RefreshToken = require('../models/RefreshToken');
const {
  generateAccessToken,
  generateRefreshToken,
  verifyRefreshToken,
  parseDuration,
} = require('../utils/jwt');

const SALT_ROUNDS = 12;

/* ── Register ────────────────────────────────────────────────── */
const register = async ({ name, gender, mobile, email, password, address, pincode }) => {
  // Check uniqueness
  const existing = await User.findOne({ where: { email } });
  if (existing) throw Object.assign(new Error('Email already registered'), { status: 409 });

  const hashedPassword = await bcrypt.hash(password, SALT_ROUNDS);

  const user = await User.create({ name, gender, mobile, email, password: hashedPassword, address, pincode });
  return safeUser(user);
};

/* ── Login ───────────────────────────────────────────────────── */
const login = async (email, password) => {
  const user = await User.findOne({ where: { email } });
  if (!user) throw Object.assign(new Error('Invalid credentials'), { status: 401 });

  const match = await bcrypt.compare(password, user.password);
  if (!match) throw Object.assign(new Error('Invalid credentials'), { status: 401 });

  const payload = { id: user.id, email: user.email };
  const accessToken = generateAccessToken(payload);
  const refreshToken = generateRefreshToken(payload);

  // Persist refresh token
  const expiresAt = new Date(Date.now() + parseDuration(process.env.REFRESH_TOKEN_EXPIRES_IN || '7d'));
  await RefreshToken.create({ user_id: user.id, token: refreshToken, expires_at: expiresAt });

  return { accessToken, refreshToken, user: safeUser(user) };
};

/* ── Refresh access token ────────────────────────────────────── */
const refreshAccessToken = async (token) => {
  const decoded = verifyRefreshToken(token); // throws if invalid/expired

  const storedToken = await RefreshToken.findOne({ where: { token, user_id: decoded.id } });
  if (!storedToken || new Date() > storedToken.expires_at) {
    throw Object.assign(new Error('Refresh token invalid or expired'), { status: 401 });
  }

  const payload = { id: decoded.id, email: decoded.email };
  const newAccessToken = generateAccessToken(payload);
  return { accessToken: newAccessToken };
};

/* ── Logout ──────────────────────────────────────────────────── */
const logout = async (refreshToken) => {
  if (refreshToken) {
    await RefreshToken.destroy({ where: { token: refreshToken } });
  }
};

/* ── Forgot / Reset password ─────────────────────────────────── */
const checkEmailExists = async (email) => {
  const user = await User.findOne({ where: { email } });
  if (!user) throw Object.assign(new Error('No account found with this email'), { status: 404 });
  return true;
};

const resetPassword = async (email, newPassword) => {
  const user = await User.findOne({ where: { email } });
  if (!user) throw Object.assign(new Error('No account found with this email'), { status: 404 });

  const hashed = await bcrypt.hash(newPassword, SALT_ROUNDS);
  await user.update({ password: hashed });

  // Invalidate all refresh tokens for security
  await RefreshToken.destroy({ where: { user_id: user.id } });
};

/* ── Helpers ─────────────────────────────────────────────────── */
const safeUser = (user) => {
  const { password, ...safe } = user.toJSON ? user.toJSON() : user;
  return safe;
};

module.exports = { register, login, refreshAccessToken, logout, checkEmailExists, resetPassword };

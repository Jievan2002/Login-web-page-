require('dotenv').config();
const app = require('./app');
const { connectDB, sequelize } = require('./config/db');

// Ensure models are registered before sync
require('./models/User');
require('./models/RefreshToken');

const PORT = process.env.PORT || 5000;

const start = async () => {
  await connectDB();

  // Sync tables without dropping existing data
  await sequelize.sync({ alter: false });
  console.log('✅ Database models synchronised');

  app.listen(PORT, () => {
    console.log(`🚀 Server running on http://localhost:${PORT}`);
    console.log(`   Environment : ${process.env.NODE_ENV}`);
  });
};

start().catch((err) => {
  console.error('Fatal startup error:', err);
  process.exit(1);
});

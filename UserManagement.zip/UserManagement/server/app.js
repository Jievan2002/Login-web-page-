const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const morgan = require('morgan');
const cookieParser = require('cookie-parser');
const rateLimit = require('express-rate-limit');
require('dotenv').config();

const authRoutes = require('./routes/authRoutes');
const userRoutes = require('./routes/userRoutes');
const { sendError } = require('./utils/response');

const app = express();

/* ── Security headers ────────────────────────────────────────── */
app.use(helmet());

/* ── CORS ────────────────────────────────────────────────────── */
const allowedOrigins = (process.env.CLIENT_ORIGIN || 'http://localhost:5173').split(',');
app.use(
  cors({
    origin: (origin, callback) => {
      if (!origin || allowedOrigins.includes(origin)) return callback(null, true);
      return callback(new Error(`CORS blocked: ${origin}`));
    },
    credentials: true,
  })
);

/* ── Rate limiting ───────────────────────────────────────────── */
const globalLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 200,
  standardHeaders: true,
  legacyHeaders: false,
  message: { success: false, message: 'Too many requests, please try again later.' },
});
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 20,
  message: { success: false, message: 'Too many auth attempts, please try again later.' },
});
app.use(globalLimiter);

/* ── Body & cookie parsers ───────────────────────────────────── */
app.use(express.json({ limit: '10kb' }));
app.use(express.urlencoded({ extended: true, limit: '10kb' }));
app.use(cookieParser());

/* ── Logger ──────────────────────────────────────────────────── */
if (process.env.NODE_ENV !== 'test') {
  app.use(morgan(process.env.NODE_ENV === 'production' ? 'combined' : 'dev'));
}

/* ── Routes ──────────────────────────────────────────────────── */
app.use('/api/auth', authLimiter, authRoutes);
app.use('/api/users', userRoutes);

/* ── Health check ────────────────────────────────────────────── */
app.get('/health', (_, res) => res.json({ status: 'OK', timestamp: new Date().toISOString() }));

/* ── 404 handler ─────────────────────────────────────────────── */
app.use((req, res) => sendError(res, `Route ${req.method} ${req.originalUrl} not found`, 404));

/* ── Global error handler ────────────────────────────────────── */
// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  console.error('Unhandled error:', err);
  const status = err.status || err.statusCode || 500;
  sendError(res, err.message || 'Internal server error', status);
});

module.exports = app;
